<!DOCTYPE html>
<html>
<head>
	<title>Input Resep</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'/assets/css/style.css' ?>" />
</head>
<body>
	<p>Nama resep : <input type="text"> </input></p>
	<p>Gambar : <input name="inputgambarresep" id="inputgambarresep" type="file"/>  </p>
	<p>Deskripsi : <input name="deskripsiresep" id="deskripsiresep" type="textarea"> </p>
	<p>Cara pembuatan : <input name="carapembuatanresep" id="carapembuatanresep" type="textarea"> </p>
</body>
</html>