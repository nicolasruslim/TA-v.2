
$(document).ready(function(){$('#sidebar').affix({
      offset: {
        top: 230,
        bottom: 100
      }
});	
$('#midCol').affix({
      offset: {
        top: 230,
        bottom: 100
      }
});	
});